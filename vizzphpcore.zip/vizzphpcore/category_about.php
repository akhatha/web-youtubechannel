<?php include "header.php" ?>

        <div id="all-output" class="col-md-10">
            <!-- Category Cover Image -->
            <div id="category-cover-image">
            	<div class="image-in">
                	<img src="images/category-img.jpg" alt="">
                </div>
            	<h1 class="title"><i class="fa fa-music"></i> Music</h1>
                <ul class="category-info">
                	<li>97,174,199 subscribers </li>
                	<li>255,525,456 Views</li>
                	<li>45,23,65 Channel No</li>
                	<li class="subscribe"><a href="#">Subscribe</a></li>
                </ul>
            </div>
            <!-- // Category Cover Image -->

            <!-- category -->
            <div id="category">
            	<div class="row">
                    <div class="col-md-2">
                        <ul class="category-menu">
                            <li><a href="category.html">Home</a></li>
                            <li><a href="category_videos.html">videos</a></li>
                            <li><a href="category_chanels.html">Chanels</a></li>
                            <li><a href="category_playlists.html">playlists</a></li>
                            <li class="active"><a href="06-category_about.html">about</a></li>
                        </ul>

                        <div class="share-in">
                        	<h1 class="title">Share in</h1>
                            <ul class="social-link">
                            	<li class="facebook"><a href="#"><i class="fa fa-facebook"></i> 11200 </a></li>
                            	<li class="twitter"><a href="#"><i class="fa fa-twitter"></i> 514 </a></li>
                            	<li class="google-plus"><a href="#"><i class="fa fa-google-plus"></i> 514 </a></li>
                            	<li class="vimeo"><a href="#"><i class="fa fa-vimeo"></i> 155 </a></li>
                            </ul>
                        </div>

                        <div class="advertising-block">
                        	<h1 class="title">Advertising</h1>
                            <div class="advertising-code">
                            	<a href="#"><img src="images/adv.jpg" alt=""></a>
                            </div>
                        </div>

                    </div><!-- // col-md-2 -->

                    <div class="col-md-10">

                        <div class="about-category">

 consectadipisicing elit, sed do eiusmod por incidid ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud lorem exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
Duis en aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi hitecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.
                        </div><!-- // about-category -->


                    </div>


                </div><!-- // row -->
            </div>
            <!-- // category -->

		</div>
      </div>
<script src="js/jquery-3.2.1.min.js"></script>
<script src="js/jquery.sticky-kit.min.js"></script>
<script src="js/custom.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/imagesloaded.pkgd.min.js"></script>
<script src="js/grid-blog.min.js"></script>



</html>
