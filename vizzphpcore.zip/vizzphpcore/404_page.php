<?php include "header.php" ?>

        <!-- // Blog-output -->
        <div id="all-output" class="col-md-10 error-page">
			<div class="row">

				<div class="col-md-4">
                	<h1 class="error-no">404</h1>
                </div><!-- // col-md-4 -->

				<div class="col-md-4">
                	<p class="error-text">
Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                    </p>
                </div><!-- // col-md-4 -->

				<div class="col-md-4">
                	<p class="error-text">
Lorem Ipsum has been the industry's standard dummy text ever since the 1500s
                    </p>
					<div class="search-form">
                        <form id="search-3" action="#" method="post">
                            <input type="text" placeholder="Search here video posts..."/>
                            <input type="submit" value="Keywords" />
                        </form>
                    </div>
                </div><!-- // col-md-4 -->


            </div><!-- // row -->
		</div><!-- // Blog-output -->
      </div>
<script src="js/jquery-3.2.1.min.js"></script>
<script src="js/jquery.sticky-kit.min.js"></script>
<script src="js/custom.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/imagesloaded.pkgd.min.js"></script>
<script src="js/grid-blog.min.js"></script>

	</body>

</html>
